package othello;
/*

Spyros Aggelopoulos 3100008
Dimitrios Mendrinos 3090122
Tsiorbatzis Andreas 3070195

*/

import java.awt.Color;
import java.awt.Font;
import java.awt.GridLayout;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.awt.event.KeyEvent;
import java.awt.image.BufferedImage;
import java.io.BufferedReader;
import java.io.File;
import java.io.IOException;
import java.io.InputStreamReader;


import javax.imageio.ImageIO;
import javax.swing.ImageIcon;
import javax.swing.JButton;
import javax.swing.JPanel;
import javax.swing.JFrame;
import javax.swing.JMenu;
import javax.swing.JMenuBar;
import javax.swing.JMenuItem;
import javax.swing.JOptionPane;

/*
To kentriko GUI tou othello. Dimiourgei ena 8x8 
GridLayout apo buttons me image .

*/

@SuppressWarnings("serial")
public class Gui extends JFrame implements ActionListener{

	JPanel panel = new JPanel();
	static JButton tiles[][] = new JButton[8][8];
	static JFrame diag ;
    JFrame leveldiag;
    static JFrame winnerdiag;
	static BufferedImage buttonIcon1 = null;
        static BufferedImage buttonIcon2 = null;
        static BufferedImage buttonIcon3 = null;
	
	static GamePlayer computer = null;
	//static GamePlayer whitePlayer = null;
	static Board board = null;
	
	static BufferedReader is = new BufferedReader(new InputStreamReader(System.in));
        static int numberofmoves=-1;
        static boolean nomovesW=false;
        static boolean nomovesB=false;
        JMenu menuA;
        JMenu menuB;
        JMenuBar menu;
        
        JMenuItem menuItem;
        JMenuItem menuItem2;
        JMenuItem menuItem3;
        
        
        int row=-1;
        int col=-1;
        
        boolean fin = false;
        boolean b1 = true;
        boolean b2 = true;
        
        Score scores=null;
	// Dimiourgei to trapezi me grafika.
	public Gui(int level, int color) {
		
		super("Othello ");
		setBounds(50, 50, 700, 700);
		setResizable(false);
		setDefaultCloseOperation(EXIT_ON_CLOSE);
		
		GridLayout grid = new GridLayout(8,8);
		panel.setLayout(grid);
                
		for(int i=0;i<8;i++)
			for(int j=0;j<8;j++){
				
				 try {
					    buttonIcon1 = ImageIO.read(new File("resource/images2.jpg"));
					    buttonIcon2 = ImageIO.read(new File("resource/black2.jpg"));
					    buttonIcon3 = ImageIO.read(new File("resource/white2.jpg"));
					    tiles[i][j] = new JButton();
					    tiles[i][j].setIcon(new ImageIcon(buttonIcon1));
					    
					    tiles[i][j].addActionListener(this);
					    
					  } catch (IOException ex) {
						  System.err.println("err");
					  }
				
				panel.add(tiles[i][j]);
			}
                /*
                To menuBar me menu settings opos: to New Game, Exit , Score
                */
                menu = new JMenuBar();
                menu.setBackground(Color.BLACK);
                menuA = new JMenu("Game");
                menuA.setForeground(Color.GREEN);
                menuA.setFont(new Font("Dialog", Font.BOLD, 16));
                menuA.setMnemonic(KeyEvent.VK_A);
                
                menuB = new JMenu("Tools");
                menuB.setForeground(Color.GREEN);
                menuB.setFont(new Font("Dialog", Font.BOLD, 16));
                menuB.setMnemonic(KeyEvent.VK_B);
                
                menuItem = new JMenuItem("New Game");
                menuItem.setFont(new Font("Dialog", Font.BOLD, 16));
                menuItem.setBackground(Color.BLACK);
                menuItem.setForeground(Color.GREEN);
                menuItem.addActionListener(new java.awt.event.ActionListener() {
                    public void actionPerformed(java.awt.event.ActionEvent evt) {
                       
                        Destructor();
                        start.visible();
                        if(scores!=null) scores.Destructor();
                    }
                });
                menuA.add(menuItem);
                
                
                menuItem2 = new JMenuItem("Exit");
                menuItem2.setFont(new Font("Dialog", Font.BOLD, 16));
                menuItem2.setBackground(Color.BLACK);
                menuItem2.setForeground(Color.GREEN);
                menuItem2.addActionListener(new java.awt.event.ActionListener() {
                    public void actionPerformed(java.awt.event.ActionEvent evt) {
                       
                    	Destructor();
                        start.Destructor();
                        if(scores!=null) scores.Destructor();
                    }
                });
                menuA.add(menuItem2);
                
                menuItem3 = new JMenuItem("Score");
                menuItem3.setFont(new Font("Dialog", Font.BOLD, 16));
                menuItem3.setBackground(Color.BLACK);
                menuItem3.setForeground(Color.GREEN);
                menuItem3.addActionListener(new java.awt.event.ActionListener() {
                    public void actionPerformed(java.awt.event.ActionEvent evt) {
                       
                    	try {
                            scores =new Score();
                        } catch (IOException ex) {
                           
                        }
                    }
                });
                menuB.add(menuItem3);
                
                menu.add(menuA);
                menu.add(menuB);
                setJMenuBar(menu);
		add(panel);
		
		setVisible(true);
		
		//System.out.println(level);
		// Otan epilexthei level setarete Gia na stalei ston minimax
                if(level == 1 || level == 2 ){
                     JOptionPane.showMessageDialog(leveldiag,
                             "Easy Level ");
                }else if(level == 3 || level == 4){
                     JOptionPane.showMessageDialog(leveldiag,
                             "Medium Level ");
                }else if(level == 5 || level == 6) {
                    JOptionPane.showMessageDialog(leveldiag,
                             "Hard Level ");
                }else {
                    JOptionPane.showMessageDialog(leveldiag,
                             "You Have to Choose Level ");
                }
                
		
		initializeOthello(level, color);
	}
	
	public static void initializeOthello(int level, int color){
		
                    
		board = new Board();

		is = new BufferedReader(new InputStreamReader(System.in));
                numberofmoves=-1;
                nomovesW=false;
                nomovesB=false;
         
                refreshTable();
                
		if(color == 1){
			
			computer = new GamePlayer(level, Board.W);
			refreshTable();
		}
		else{
			
			computer = new GamePlayer(level, Board.B);
			refreshTable();
			computerMove();
			
		}

	}
	//H koinisi tou paikti pou dialeksame.

	public static boolean playerMove(ActionEvent a){
		
        numberofmoves=board.countValidMoves(false);
        //System.out.println("~~~~~~~ "+numberofmoves+" moves");
        Move playerMove;
		
   
        if(numberofmoves>0){
        	
        	int row=-1;
        	int col=-1;
        	
        	 for (int n = 0; n < 8; n++) 
        	    for (int j = 0; j < 8; j++) 
        	       if(a.getSource()== tiles[n][j])
        	       {
        	             row=n;
        	             col=j;
        	       }
             playerMove = new Move(row,col);
			
            if(board.isValidMove(playerMove.getRow(), playerMove.getCol()) && playerMove.getRow()!= -1 && playerMove.getCol()!=-1 ){
				board.makeMove(playerMove.getRow(), playerMove.getCol(),  -board.getLastLetterPlayed());
				 refreshTable();
   
            }
            else{
            	
            	JOptionPane.showMessageDialog(diag,
                "Invalid Move");
            }
            
            return true;
        
        }
        else{
        	
        	board.setLastLetterPlayed(-board.getLastLetterPlayed());
             JOptionPane.showMessageDialog(diag,
                 "You have no ove");
             
             return false;
        	
        }
    
		
	}
	// Kaleite o minimax gia tin kinisi tou Ypologisti.
	public static boolean computerMove(){
		
		 Move computermove;
         
		    board.DisplayScore();
            numberofmoves=board.countValidMoves(false);
       
         if(numberofmoves>0){
		         	
		        	 computermove= computer.MiniMax(board);
		            
		         			
		             if(board.isValidMove(computermove.getRow(), computermove.getCol()) && computermove.getRow()!= -1 && computermove.getCol()!=-1 ){
							board.makeMove(computermove.getRow(), computermove.getCol(), -board.getLastLetterPlayed());
							
							refreshTable();
							
		                     
		             }
		             
		             return true;

         }  
         else{
         	
         	board.setLastLetterPlayed(-board.getLastLetterPlayed());
         	
             JOptionPane.showMessageDialog(diag,
                  "Computer has no Moves");
             
             return false;
         	
     	}
		
		
	}
	// Ean plirounte oi proupotheseis ilopoihte kai sto CLICK ekteleite h kinisi.
	public void actionPerformed(ActionEvent a){
        
        if(!b1 && !b2) fin = endgame();
        
        else {
        	
        	
        	if(!board.isTerminal() )
			{   
				if(board.getLastLetterPlayed()== computer.getLetter()) b1 = playerMove(a);
	
	        }
			else{
				
				if(!fin) fin = endgame();
				
			}
			if(!board.isTerminal())
			{   
	
				if(board.getLastLetterPlayed()== -computer.getLetter() )b2 = computerMove();
	        }
			else{
				
				if(!fin) fin = endgame();
			}
			if(board.isTerminal()){
				
				if(!fin) fin = endgame();
			}
		
        }
        
        if(scores!=null) scores.init();
                
	} 
        //Dialog Bars gia tin emfanisi tou nikiti.
	public static boolean endgame(){

		
		 if (board.getWinner() == 1){
             JOptionPane.showMessageDialog(winnerdiag,
                 "BLACK WINS ! Black: "+board.ScoreCount(1)+" White : "+ board.ScoreCount(-1));
        }else if(board.getWinner() == -1) {
            JOptionPane.showMessageDialog(winnerdiag,
                 "WHITE WINS! White : "+board.ScoreCount(-1) + " Black : "+ board.ScoreCount(1));
        }else {
            JOptionPane.showMessageDialog(winnerdiag,
                 "DRAW! White : "+board.ScoreCount(-1) + " Black : "+ board.ScoreCount(1));
        }
		 
		 return true;
	}

	public static void refreshTable(){
		
		for(int row=0; row<8; row++)
		{
			for(int col=0; col<8; col++)
			{

				if(board.getGameBoard()[row][col] == Board.B){
					tiles[row][col].setIcon(new ImageIcon(buttonIcon2));
                                    
}
				else if(board.getGameBoard()[row][col] == Board.W){
					tiles[row][col].setIcon(new ImageIcon(buttonIcon3));}
				else {tiles[row][col].setIcon(new ImageIcon(buttonIcon1));}
			}
		
		}
             

	}
        
       
    public void Destructor(){
            
            this.dispose();
    }

}
