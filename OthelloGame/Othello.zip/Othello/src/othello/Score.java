/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package othello;

import java.awt.Color;
import java.awt.Font;
import java.awt.image.BufferedImage;
import java.io.IOException;
import javax.swing.JFrame;
import javax.swing.JLabel;
import javax.swing.JPanel;
import static othello.Gui.board;
import javax.swing.GroupLayout;
import javax.swing.GroupLayout.Alignment;
import javax.swing.LayoutStyle.ComponentPlacement;

/*

Spyros Aggelopoulos 3100008
Dimitrios Mendrinos 3090122
Tsiorbatzis Andreas 3070195

*/

@SuppressWarnings("serial")
public class Score extends JFrame {

    /**
     * @param args the command line arguments
     */
    JLabel scoreB ;
    JLabel scoreW ;
    JPanel panel = new JPanel();
    static BufferedImage score = null ;
    static Score scores;
    
       
    
    public Score() throws IOException{
    	
    	super("Othello");	
    	init();
    	setVisible(true);
    }
    /*
    Se autin tin Class ilopoihte to grafiko Perivallon
    gia ena frame pou mas parousiazei to Score 
    stin periptosi pou patithei apo to Menu BAR
    */
    public void init(){
    	
    	panel.removeAll();
    	setBounds(760, 50,250,200);
        setResizable(false);
        scoreB = new JLabel ("Score of Black : "+board.ScoreCount(1));
        scoreB.setFont(new Font("Dialog", Font.PLAIN, 18));
        scoreW = new JLabel ("Score of White : "+board.ScoreCount(-1));
        scoreW.setBackground(Color.BLACK);
        scoreW.setFont(new Font("Dialog", Font.PLAIN, 18));
        panel.setBackground(Color.BLACK);
        scoreB.setForeground(Color.GREEN);
        scoreW.setForeground(new Color(0, 255, 0));
        GroupLayout groupLayout = new GroupLayout(getContentPane());
        groupLayout.setHorizontalGroup(
        	groupLayout.createParallelGroup(Alignment.LEADING)
        		.addGroup(groupLayout.createSequentialGroup()
        			.addComponent(panel, GroupLayout.PREFERRED_SIZE, 278, GroupLayout.PREFERRED_SIZE)
        			.addContainerGap(266, Short.MAX_VALUE))
        );
        groupLayout.setVerticalGroup(
        	groupLayout.createParallelGroup(Alignment.LEADING)
        		.addGroup(groupLayout.createSequentialGroup()
        			.addComponent(panel, GroupLayout.PREFERRED_SIZE, 225, GroupLayout.PREFERRED_SIZE)
        			.addContainerGap(547, Short.MAX_VALUE))
        );
        GroupLayout gl_panel = new GroupLayout(panel);
        gl_panel.setHorizontalGroup(
        	gl_panel.createParallelGroup(Alignment.LEADING)
        		.addGroup(gl_panel.createSequentialGroup()
        			.addGap(34)
        			.addGroup(gl_panel.createParallelGroup(Alignment.LEADING)
        				.addComponent(scoreW, GroupLayout.PREFERRED_SIZE, 188, GroupLayout.PREFERRED_SIZE)
        				.addComponent(scoreB, GroupLayout.PREFERRED_SIZE, 183, GroupLayout.PREFERRED_SIZE))
        			.addContainerGap(172, Short.MAX_VALUE))
        );
        gl_panel.setVerticalGroup(
        	gl_panel.createParallelGroup(Alignment.LEADING)
        		.addGroup(gl_panel.createSequentialGroup()
        			.addGap(26)
        			.addComponent(scoreB, GroupLayout.PREFERRED_SIZE, 62, GroupLayout.PREFERRED_SIZE)
        			.addPreferredGap(ComponentPlacement.RELATED)
        			.addComponent(scoreW, GroupLayout.PREFERRED_SIZE, 69, GroupLayout.PREFERRED_SIZE)
        			.addGap(209))
        );
        panel.setLayout(gl_panel);
        getContentPane().setLayout(groupLayout);
        
        panel.revalidate();
        panel.repaint();
        
    }
    
    public void Destructor(){
        
        this.dispose();
    }
}
