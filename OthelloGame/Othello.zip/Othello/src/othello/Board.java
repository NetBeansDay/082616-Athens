package othello;

/*

Spyros Aggelopoulos 3100008
Dimitrios Mendrinos 3090122
Tsiorbatzis Andreas 3070195

*/


import java.util.ArrayList;

/*
Board Class. Ylopoih Tou vasikous kanones tou board 
*/

public class Board
{
    //Variables for the Boards values
	public static final int B = 1;
	public static final int W = -1;
	public static final int EMPTY = 0;
    
    //Immediate move that lead to this board
    private Move lastMove;

    /* Variable containing who played last; whose turn resulted in this board
     * Even a new Board has lastLetterPlayed value; it denotes which player will play first
     */
	private int lastLetterPlayed;
        
	private int [][] gameBoard;
	
	private ArrayList<Move> changeColorList;
    // Dimiourgite enas pinakas 8x8 opou exei ta basic mavra kai leuka poulia .
    public Board()
    {
		lastMove = new Move();
		lastLetterPlayed = W;
		
		changeColorList = new ArrayList<Move>();
		
		gameBoard = new int[8][8];
		for(int i=0; i<8; i++)
		{
	            for(int j=0; j<8; j++)
	            {
			gameBoard[i][j] = EMPTY;
	            }
	    }
	        
        gameBoard[3][3] = B;
        gameBoard[3][4] = W;
        gameBoard[4][4] = B;
        gameBoard[4][3] = W;

       
        
    }
	
    public Board(Board board)
	{
		lastMove = board.lastMove;
		lastLetterPlayed = board.lastLetterPlayed;
		changeColorList = board.changeColorList;
		
		gameBoard = new int[8][8];
		for(int i=0; i<8; i++)
		{
			for(int j=0; j<8; j++)
			{
				gameBoard[i][j] = board.gameBoard[i][j];
			}
		}
	}
		
	public ArrayList<Move> getChangeColorList() {
		
		return changeColorList;
	}

	public void setChangeColorList(ArrayList<Move> changeColorList) {
		
		this.changeColorList = changeColorList;
	}

	public Move getLastMove()
	{
		return lastMove;
	}
	
	public int getLastLetterPlayed()
	{
		return lastLetterPlayed;
	}
	
	public int[][] getGameBoard()
	{
		return gameBoard;
	}
        //Getters & Setters
	public void setLastMove(Move lastMove)
	{
		this.lastMove.setRow(lastMove.getRow());
		this.lastMove.setCol(lastMove.getCol());
		this.lastMove.setValue(lastMove.getValue());
	}
	
	public void setLastLetterPlayed(int lastLetterPlayed)
	{
		this.lastLetterPlayed = lastLetterPlayed;
	}
	
    public void setGameBoard(int[][] gameBoard)
	{
		for(int i=0; i<8; i++)
		{
			for(int j=0; j<8; j++)
			{
				this.gameBoard[i][j] = gameBoard[i][j];
			}
		}
	}

    //Make a move; it places a letter in the board
	public void makeMove(int row, int col, int letter)
	{
		gameBoard[row][col] = letter;
		refreshTable(row,col);
		lastMove = new Move(row, col);
		lastLetterPlayed = letter;
            
	}
	
	public void refreshTable(int row,int col){
		
		for(Move m : changeColorList){
			//System.out.println(m.getRow()+"-----"+m.getCol());
			gameBoard[m.getRow()][m.getCol()] = -lastLetterPlayed; 
		}
		
		changeColorList.clear();
	}
	public int countValidMoves(boolean opponent){
		
		int count = 0;
		if(!opponent){
			for(int i=0; i<8; i++)
				for(int j=0; j<8; j++)
					if(isValidMove(i,j)) count++;
		}
		else{
			lastLetterPlayed = -lastLetterPlayed;
			for(int i=0; i<8; i++)
				for(int j=0; j<8; j++)
					if(isValidMove(i,j)) count++;
			lastLetterPlayed = -lastLetterPlayed;
		}
		
		return count;
	}

    //Checks whether a move is valid; whether a square is empty
	public boolean isValidMove(int row, int col)
	{
		changeColorList.clear();
		
		if (!InBounds(row, col))
		{
			return false;
		}
		if(gameBoard[row][col] != EMPTY)
		{
			return false;
		}
		if( InBounds(row-1, col-1) && gameBoard[row-1][col-1] == lastLetterPlayed){
			
			searchAround(row-1,col-1, -1,-1);
		}
		if( InBounds(row-1, col) && gameBoard[row-1][col] == lastLetterPlayed){
			
			searchAround(row-1,col,-1,0);
		}
		if( InBounds(row-1, col+1) && gameBoard[row-1][col+1] == lastLetterPlayed){
			
			searchAround(row-1,col+1,-1,1);
		}		
		if( InBounds(row, col-1) && gameBoard[row][col-1] == lastLetterPlayed){
			
			searchAround(row,col-1,0,-1);
		}
		if( InBounds(row, col+1) && gameBoard[row][col+1] == lastLetterPlayed){
			
			searchAround(row,col+1,0,1);
		}
		if( InBounds(row+1, col-1) && gameBoard[row+1][col-1] == lastLetterPlayed){
			
			searchAround(row+1,col-1,1,-1);
		}
		if( InBounds(row+1, col) && gameBoard[row+1][col] == lastLetterPlayed){
			
			searchAround(row+1,col,1,0);
		}
		if( InBounds(row+1, col+1) && gameBoard[row+1][col+1] == lastLetterPlayed){
			
			searchAround(row+1,col+1,1,1);
		}
		
		return (  !changeColorList.isEmpty()  );
	}
	// Psaxnei se ka8e diastash gia pionia tou idiou xrwmatos
	@SuppressWarnings("unchecked")
	public void searchAround(int row, int col,int xdirection, int ydirection){
		
		ArrayList<Move> tmp = (ArrayList<Move>) changeColorList.clone();
		boolean hasEnd=false;
		while(InBounds(row, col)){
			
			if(gameBoard[row][col] == -lastLetterPlayed){
				hasEnd=true;
				break;
			}
			else if (gameBoard[row][col] == lastLetterPlayed) tmp.add(new Move(row, col, lastLetterPlayed));
			else break;
			//System.out.println(row+","+col);

			row+= xdirection;
			col+= ydirection;
			
		}
		if(hasEnd) changeColorList=tmp;

	}
	
	public boolean InBounds(int row, int col){
		
		return (  (row >= 0) && (row < 8)   &&   (col >= 0) && (col < 8)  );
	}


    /* Generates the children of the state
     * Any square in the board that is empty results to a child
     */
	public ArrayList<Board> getChildren(int letter)
	{
		ArrayList<Board> children = new ArrayList<Board>();
		for(int row=0; row<8; row++)
		{
			for(int col=0; col<8; col++)
			{
				if(isValidMove(row, col))
				{
					Board child = new Board(this);
					child.makeMove(row, col, letter);
					children.add(child);
				}
			}
		}
		return children;
	}

	/*
     * The heuristic function
     */
	public double evaluate()
	{
		int playerpieces = 0 ;
		int opponentpieces = 0;
		int playerstable = 0 ; 
		int opponentstable = 0;
		double piecesratio = 0, moveratio = 0, stability = 0, weightcount = 0;
		double[] cornerratio= new double[2];
		
		int boardweights[][] ={{20, -20, 5, 4, 4, 5, -20, 20},
								{-20, -25, -2, 1, 1, -2, -25, -20},
								{5, -2, 1, 1, 1, 1, -2, 5},
								{4, 1, 1, -2, -2, 1, 1, 4},
								{4, 1, 1, -2, -2, 1, 1, 4},
								{5, -2, 1, 1, 1, 1, -2, 5},
								{-15,-18, -2, 1, 1, -2, -25, -20},
								{20, -15, 5, 4, 4, 5, -20, 20}};

		cornerratio = evaluateCorners();
		
	// Piece difference, frontier disks and disk squares
		for(int i=0; i<8; i++)
			for(int j=0; j<8; j++)  {
				if(gameBoard[i][j] == -lastLetterPlayed)  {
					weightcount += boardweights[i][j];
					playerpieces++;
				} else if(gameBoard[i][j] == lastLetterPlayed)  {
					weightcount -= boardweights[i][j];
					opponentpieces++;
				}
				if(gameBoard[i][j] != EMPTY)   {
					
					if ( (isStable( i, j, 1, 0) || isStable( i, j, -1, 0) ) &&	(isStable( i, j, 0, 1) || isStable( i, j, 0, -1) ) &&
							 (isStable( i, j, 1, 1) || isStable( i, j, -1, -1) ) &&   (isStable( i, j, 1, -1) || isStable( i, j, -1, 1) ) ) {
						
							if (gameBoard[i][j] == -lastLetterPlayed) playerstable++;
							else opponentstable++;
						}

				}
			}
		
		if(playerpieces > opponentpieces)
			piecesratio = (100.0 * playerpieces)/(playerpieces + opponentpieces);
		else if(playerpieces < opponentpieces)
			piecesratio = -(100.0 * opponentpieces)/(playerpieces + opponentpieces);
		else piecesratio = 0;

		if(playerstable > opponentstable)
			stability = -(100.0 * playerstable)/(playerstable + opponentstable);
		else if(playerstable < opponentstable)
			stability = (100.0 * opponentstable)/(playerstable + opponentstable);
		else stability = 0;

	// Mobility
		playerpieces = countValidMoves(false);
		opponentpieces = countValidMoves(true);
		if(playerpieces > opponentpieces)
			moveratio = (100.0 * playerpieces)/(playerpieces + opponentpieces);
		else if(playerpieces < opponentpieces)
			moveratio = -(100.0 * opponentpieces)/(playerpieces + opponentpieces);
		else moveratio = 0;

	// final weighted score
		double score = (10 * piecesratio) + (1500 * cornerratio[0]) +(2000 * cornerratio[1])  + (80 * moveratio) + (250 * stability) + (50 * weightcount);
		return score;
		
		
		
	}
	/*
        H evaluation tou othello. Aksiologei tis theseis kai tin kathe kinisi
        analogos me tin simantikotita. 
        */
	private double[] evaluateCorners(){
		
		// Corner closeness
		int playercorners =0 ;
		int opponentcorners = 0;
		int playerdanger =0 ;
		int opponendanger = 0;
		
		
		if(gameBoard[0][0] == -lastLetterPlayed) playercorners+=4;
		else if(gameBoard[0][0] == lastLetterPlayed) opponentcorners+=4;
		else{
			if(gameBoard[0][1] == -lastLetterPlayed) playerdanger--;
			else if(gameBoard[0][1] == lastLetterPlayed) opponendanger--;
			if(gameBoard[1][1] == -lastLetterPlayed) playerdanger--;
			else if(gameBoard[1][1] == lastLetterPlayed) opponendanger--;
			if(gameBoard[1][0] == -lastLetterPlayed) playerdanger--;
			else if(gameBoard[1][0] == lastLetterPlayed) opponendanger--;
		}
		
		
		if(gameBoard[0][7] == -lastLetterPlayed) playercorners+=4;
		else if(gameBoard[0][7] == lastLetterPlayed) opponentcorners+=4;
		else {
			if(gameBoard[0][6] == -lastLetterPlayed) playerdanger--;
			else if(gameBoard[0][6] == lastLetterPlayed) opponendanger--;
			if(gameBoard[1][6] == -lastLetterPlayed) playerdanger--;
			else if(gameBoard[1][6] == lastLetterPlayed) opponendanger--;
			if(gameBoard[1][7] == -lastLetterPlayed) playerdanger--;
			else if(gameBoard[1][7] == lastLetterPlayed) opponendanger--;
		}
		
		
		if(gameBoard[7][0] == -lastLetterPlayed) playercorners+=4;
		else if(gameBoard[7][0] == lastLetterPlayed) opponentcorners+=4;
		else {
			if(gameBoard[7][1] == -lastLetterPlayed) playerdanger--;
			else if(gameBoard[7][1] == lastLetterPlayed) opponendanger--;
			if(gameBoard[6][1] == -lastLetterPlayed) playerdanger--;
			else if(gameBoard[6][1] == lastLetterPlayed) opponendanger--;
			if(gameBoard[6][0] == -lastLetterPlayed) playerdanger--;
			else if(gameBoard[6][0] == lastLetterPlayed) opponendanger--;
		}
		
		
		if(gameBoard[7][7] == -lastLetterPlayed) playercorners+=4;
		else if(gameBoard[7][7] == lastLetterPlayed) opponentcorners+=4;
		else {
			if(gameBoard[6][7] == -lastLetterPlayed) playerdanger--;
			else if(gameBoard[6][7] == lastLetterPlayed) opponendanger--;
			if(gameBoard[6][6] == -lastLetterPlayed) playerdanger--;
			else if(gameBoard[6][6] == lastLetterPlayed) opponendanger--;
			if(gameBoard[7][6] == -lastLetterPlayed) playerdanger--;
			else if(gameBoard[7][6] == lastLetterPlayed) opponendanger--;
		}
		
		return  new double[]{6.25 * ((playercorners - opponentcorners)), 3.12 * ((playercorners - opponentcorners))};
	}
	// Voithitiki methodos tis Evaluation . Elegxei an mia seira einai kerdismeni
	private boolean isStable(int row, int col, int x, int y) {
		
		boolean stable = true;
		while ( InBounds(row+x, col+y) && stable) {
			
			if (gameBoard[row+x][col+y] == lastLetterPlayed) {
				stable = false;
			}
			row += x;
			col += y;
		}
		return stable;
	}
	//Metraei to Score.
	public int ScoreCount(int player){
		
		int score=0;
		
        for(int i=0; i<8; i++){
            for(int j=0; j<8; j++){
                
                if (gameBoard[i][j]== player) score++;
            }
        }
        
        return score;
	}
        
        //Emfanisei tou Score se Command Line
    public void DisplayScore(){
    	
        int scoreB=ScoreCount(Board.B);
        int scoreW=ScoreCount(Board.W);
        
        //System.out.println("Black :"+scoreB+" White: "+scoreW);
    }
    //Getter tou nikiti.
    public int getWinner(){
        if(ScoreCount(Board.B)>ScoreCount(Board.W)){
            return Board.B;
        }else return Board.W;
    }
    
    //Epistrefei true an o pinakas einai gematos
    public boolean isTerminal()
    {
        for(int i=0;i<8;i++){
        	
        	for(int j=0;j<8;j++){
        		
            	if(gameBoard[i][j]==0)
            		return false;
            }
        }
        
        return true;
    }

    //Prints the board
	public void print()
	{
		System.out.println("*******************");
		for(int row=0; row<8; row++)
		{
			System.out.print("* ");
			for(int col=0; col<8; col++)
			{
				switch (gameBoard[row][col])
				{
					case B:
						System.out.print("B ");
						break;
					case W:
						System.out.print("W ");
						break;
					case EMPTY:
						System.out.print("- ");
						break;
					default:
						break;
				}
			}
			System.out.println("*");
		}
		System.out.println("*******************");
	}
}
