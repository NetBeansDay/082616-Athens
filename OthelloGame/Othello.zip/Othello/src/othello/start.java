package othello;
/*

Spyros Aggelopoulos 3100008
Dimitrios Mendrinos 3090122
Tsiorbatzis Andreas 3070195

*/

import java.awt.EventQueue;

import javax.imageio.ImageIO;
import javax.swing.ButtonGroup;
import javax.swing.ImageIcon;
import javax.swing.JFrame;
import javax.swing.GroupLayout;
import javax.swing.GroupLayout.Alignment;
import javax.swing.JRadioButton;
import javax.swing.LayoutStyle.ComponentPlacement;
import javax.swing.JLabel;
import javax.swing.JButton;
import java.awt.event.ActionListener;
import java.awt.event.ActionEvent;
import java.awt.image.BufferedImage;
import java.awt.Font;
import java.io.File;
import java.io.IOException;

@SuppressWarnings("serial")
public class start extends JFrame{

	private JFrame frame;
	ImageIcon image;
	static int level = 0 ;
	static int color = 0 ;
	static Gui gui;
	static start window;
	static BufferedImage buttonIcon1 = null;

	/**
	 * Launch the application.
         * To arxiko mas FRAME. 
	 */
	public static void main(String[] args) {
		EventQueue.invokeLater(new Runnable() {
			public void run() {
				try {
					
					window = new start();
					window.frame.setVisible(true);
				} catch (Exception e) {
					e.printStackTrace();
				}
			}
		});
	}

	/**
	 * Create the application.
	 */
	public start() {
		initialize();
	}

	/**
	 * Initialize the contents of the frame.
	 */
	private void initialize() {
		
		ImageIcon image = new ImageIcon("resource/logo.jpg");
		
		frame = new JFrame();
		frame.getContentPane().setFont(new Font("Dialog", Font.PLAIN, 14));
		frame.setResizable(false);
		frame.setBounds(50, 50, 700, 700);
		frame.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
		//Level Buttons
		JRadioButton rdbtnNewRadioButton = new JRadioButton("Easy");
		rdbtnNewRadioButton.setFont(new Font("Dialog", Font.PLAIN, 14));
		rdbtnNewRadioButton.setActionCommand("Easy");
		//Level Buttons
		JRadioButton rdbtnNewRadioButton_1 = new JRadioButton("Medium");
		rdbtnNewRadioButton_1.setFont(new Font("Dialog", Font.PLAIN, 14));
		rdbtnNewRadioButton_1.setActionCommand("Medium");
		//Level Buttons
		JRadioButton rdbtnNewRadioButton_2 = new JRadioButton("Hard");
		rdbtnNewRadioButton_2.setFont(new Font("Dialog", Font.PLAIN, 14));
		rdbtnNewRadioButton_2.setActionCommand("Hard");
		
		JLabel lblNewLabel = new JLabel("Select level of difficulty:");
		lblNewLabel.setFont(new Font("Tahoma", Font.BOLD, 14));
		
		JButton btnNewButton = new JButton("PLAY");
		btnNewButton.setFont(new Font("Tahoma", Font.BOLD, 30));
		
		JLabel lblSelectColour = new JLabel("Select colour:");
		lblSelectColour.setFont(new Font("Tahoma", Font.BOLD, 14));
		
		JRadioButton rdbtnBlack = new JRadioButton("Black");
		rdbtnBlack.setFont(new Font("Dialog", Font.PLAIN, 14));
		rdbtnBlack.setActionCommand("Black");
		
		JRadioButton rdbtnWhite = new JRadioButton("White");
		rdbtnWhite.setFont(new Font("Dialog", Font.PLAIN, 14));
		rdbtnWhite.setActionCommand("White");
		
		JLabel lblNewLabel_1 = new JLabel("");
		lblNewLabel_1.setBounds(0, 0, 100, 100);
		lblNewLabel_1.setIcon(image);
		
		final ButtonGroup bg = new ButtonGroup();
		bg.add(rdbtnBlack);
		bg.add(rdbtnWhite);
		
		final ButtonGroup bg2 = new ButtonGroup();
		bg2.add(rdbtnNewRadioButton);
		bg2.add(rdbtnNewRadioButton_1);
		bg2.add(rdbtnNewRadioButton_2);
		
		//Molis patithei ena button stelnete to antistoixo level
                //Alla kai i epilogi tou antistoixou paikti.
		btnNewButton.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent arg0) {
				
                try{
                    if(bg.getSelection().getActionCommand().equals("Black")){
                        color = 1;
                    }else {
                        color = 2;
                    }
                    
                    if(bg2.getSelection().getActionCommand().equals("Easy")){
                        level = 0+ color;
                    }else if(bg2.getSelection().getActionCommand().equals("Medium")){
                        level = 2 + color;
                    }else {
                        level = 4 + color;
                    }
                    

                    
                    
                    if(level!=0 && color!=0){
                          gui = new Gui(level,color);
                          window.frame.setVisible(false);
                          //System.out.println(level);
                    }
                    }
                    catch(NullPointerException ex){
                    	
                    	
                    }
			}
		});
		
		try {
			buttonIcon1 = ImageIO.read(new File("resource/play.png"));
			btnNewButton.setIcon(new ImageIcon(buttonIcon1));
			
		} catch (IOException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		
		GroupLayout groupLayout = new GroupLayout(frame.getContentPane());
		groupLayout.setHorizontalGroup(
			groupLayout.createParallelGroup(Alignment.LEADING)
				.addGroup(groupLayout.createSequentialGroup()
					.addContainerGap()
					.addComponent(lblNewLabel_1, GroupLayout.DEFAULT_SIZE, 664, Short.MAX_VALUE)
					.addContainerGap())
				.addComponent(btnNewButton, GroupLayout.DEFAULT_SIZE, 684, Short.MAX_VALUE)
				.addGroup(groupLayout.createSequentialGroup()
					.addGap(44)
					.addGroup(groupLayout.createParallelGroup(Alignment.LEADING)
						.addGroup(groupLayout.createSequentialGroup()
							.addComponent(lblSelectColour, GroupLayout.PREFERRED_SIZE, 147, GroupLayout.PREFERRED_SIZE)
							.addContainerGap())
						.addGroup(groupLayout.createSequentialGroup()
							.addGroup(groupLayout.createParallelGroup(Alignment.LEADING)
								.addGroup(groupLayout.createSequentialGroup()
									.addGroup(groupLayout.createParallelGroup(Alignment.LEADING)
										.addGroup(groupLayout.createSequentialGroup()
											.addGap(51)
											.addComponent(rdbtnNewRadioButton)
											.addPreferredGap(ComponentPlacement.RELATED, 170, Short.MAX_VALUE)
											.addComponent(rdbtnNewRadioButton_1)
											.addGap(144))
										.addGroup(groupLayout.createSequentialGroup()
											.addGap(50)
											.addComponent(rdbtnBlack)
											.addPreferredGap(ComponentPlacement.RELATED)))
									.addGroup(groupLayout.createParallelGroup(Alignment.LEADING)
										.addComponent(rdbtnNewRadioButton_2)
										.addComponent(rdbtnWhite)))
								.addGroup(groupLayout.createSequentialGroup()
									.addComponent(lblNewLabel)
									.addPreferredGap(ComponentPlacement.RELATED, 406, GroupLayout.PREFERRED_SIZE)))
							.addGap(97))))
		);
		groupLayout.setVerticalGroup(
			groupLayout.createParallelGroup(Alignment.TRAILING)
				.addGroup(groupLayout.createSequentialGroup()
					.addContainerGap()
					.addComponent(lblNewLabel_1, GroupLayout.DEFAULT_SIZE, 405, Short.MAX_VALUE)
					.addGap(17)
					.addComponent(lblSelectColour, GroupLayout.PREFERRED_SIZE, 15, GroupLayout.PREFERRED_SIZE)
					.addPreferredGap(ComponentPlacement.UNRELATED)
					.addGroup(groupLayout.createParallelGroup(Alignment.BASELINE)
						.addComponent(rdbtnBlack)
						.addComponent(rdbtnWhite))
					.addGap(18)
					.addComponent(lblNewLabel)
					.addPreferredGap(ComponentPlacement.UNRELATED)
					.addGroup(groupLayout.createParallelGroup(Alignment.BASELINE)
						.addComponent(rdbtnNewRadioButton)
						.addComponent(rdbtnNewRadioButton_2)
						.addComponent(rdbtnNewRadioButton_1))
					.addGap(18)
					.addComponent(btnNewButton, GroupLayout.PREFERRED_SIZE, 96, GroupLayout.PREFERRED_SIZE))
		);
		frame.getContentPane().setLayout(groupLayout);
	}
	
    public static void Destructor(){
    	window.frame.dispose();
    }
    
    public static void visible(){
    	window.frame.setVisible(true);
    }
}
