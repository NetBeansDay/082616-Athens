/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package othello;

/*

Spyros Aggelopoulos 3100008
Dimitrios Mendrinos 3090122
Tsiorbatzis Andreas 3070195

*/
//Move Class. 
public class Move {
    
	private int row;
	private int col;
	private double value;
	//Consturctor
	public Move()
	{
		row = -1;
		col = -1;
		value = 0;
	}
	
	public Move(int row, int col)
	{
		this.row = row;
		this.col = col;
		this.value = 0;
	}
	
	public Move(double value)
	{
		this.row = -1;
		this.col = -1;
		this.value = value;
	}
	
	public Move(int row, int col, double value)
	{
		this.row = row;
		this.col = col;
		this.value = value;
	}
	//Getters & Setters
	public int getRow()
	{
		return row;
	}
	
	public int getCol()
	{
		return col;
	}
	
	public double getValue()
	{
		return value;
	}
	
	public void setRow(int row)
	{
		this.row = row;
	}
	
	public void setCol(int col)
	{
		this.col = col;
	}
	
	public void setValue(double value)
	{
		this.value = value;
	}


}
